import re
import pandas as pd
df = pd.DataFrame()
def fnExtractPremiumandPayble(word,df):
    print(word)
    #word = 'Your first drawing of £ 4,050.00 under this Agreement 4,455.00'
    #filename = re.match(r'\d{1,5}[,]\d{1,2}\d{1,2}[,.]\d{1,2}', word)
    filename = re.findall(r'\d{1,5}[,]\d{1,2}\d{1,2}[,.]\d{1,2}', word)
    df.loc[0,'Premium Amount']= filename[0]
    df.loc[0,'Balance Payble'] = filename[1]
    return df
def fnGrossRate(word,df):
    print(word)
    #word = 'under this Agreement will be 10.00 %. The annual rate of interest is equal'
    # filename = re.match(r'\d{1,5}[,]\d{1,2}\d{1,2}[,.]\d{1,2}', word)
    filename = re.findall(r'\d{1,3}[.,]\d{1,2}', word)
    df.loc[0,'Gross Rate'] = filename
    return df
def perAnnumRate(df):
    word = 'Agreement is 15.00 %, assuming that the drawing is repaid in 9 installment'
    # filename = re.match(r'\d{1,5}[,]\d{1,2}\d{1,2}[,.]\d{1,2}', word)
    filename = re.findall(r'\d{1,3}[.,]\d{1,2}', word)
    df.loc[0,'Annum Rate'] = filename
    print(filename)
    return df
def installment(df):
    word = 'Agreement is 15.00 %, assuming that the drawing is repaid in 9 installment'
    # filename = re.match(r'\d{1,5}[,]\d{1,2}\d{1,2}[,.]\d{1,2}', word)
    filename1 = re.findall(r'in\s\d{1,3}\sinstallment', word)
    filename = re.findall('\d{1,3}',str(filename1))
    print(filename)
    df.loc[0,'Installment']= filename
    return df
def indicativeTotalAmt(word,df):
    #word = 'pay under this Agreement would be  £ 1,380.00'
    # filename = re.match(r'\d{1,5}[,]\d{1,2}\d{1,2}[,.]\d{1,2}', word)
    filename = re.findall(r'\d{1,5}[,]\d{1,2}\d{1,2}[,.]\d{1,2}', word)
    print(filename)
    df.loc[0, 'Indicative Total Amount'] = filename
    return df
def fnExtractAPR(word,df):
    #word = 'The APR under this agreement is 30.12 %, based on the assumptions tha'
    # filename = re.match(r'\d{1,5}[,]\d{1,2}\d{1,2}[,.]\d{1,2}', word)
    filename = re.findall(r'\d{1,3}[.,]\d{1,2}', word)
    print(filename)
    df.loc[0, 'APR'] = filename
    return df
def fnFacilityFee(df):
    word = 'The facility fee for the first drawing made under this Agreement will be £ 0.00'
    # filename = re.match(r'\d{1,5}[,]\d{1,2}\d{1,2}[,.]\d{1,2}', word)
    filename = re.findall(r'\d{1,3}[.,]\d{1,2}', word)
    df.loc[0, 'Facility Fee'] = filename
    return df
def fnCreditArrangementFee(word,df):
    print("incredit", word)
    #word = 'you a credit arrangement fee of £ 0.00'
    # filename = re.match(r'\d{1,5}[,]\d{1,2}\d{1,2}[,.]\d{1,2}', word)
    filename = re.findall(r'\d{1,3}[.,]\d{1,2}', word)
    print(filename)
    df.loc[0, 'Credit Agreement Fee'] = filename
    return df

def fnExtractallStreamData(df):
    print("inside test page")
    fnPP = fnExtractPremiumandPayble(df)
    grossRate = fnGrossRate(fnPP)
    annumRate = perAnnumRate(grossRate)
    inment = installment(annumRate)
    itotalamt = indicativeTotalAmt(inment)
    apr =fnExtractAPR(itotalamt)
    fFees = fnFacilityFee(apr)
    crAggrement = fnCreditArrangementFee(fFees)
    crAggrement.to_csv(r'C:\Users\Srikant Padhy\PycharmProjects\CBL\Output\streamdata.csv')
    return crAggrement

# import pandas as pd
# dic = {'DOB': 'test', 'Address': 'xyz', 'Broker Address': 'abcd efg', 'Post Code': '102050', 'Name': 'chinu'}
# originalformatpath = r"C:\Users\Srikant Padhy\project\output\test.csv"
# df = pd.read_csv(originalformatpath, sep='\n')
# df1 = pd.DataFrame()
# for data in df['Field']:
#     for key,val in dic.items():
#         if data==key:
#             df1.loc[0,data] = val
#         else:
#             df1.loc[1,data] = ' '
# df1.drop(index=[1],inplace=True)
#
# #df1 = df1.transpose()
# df1.to_csv(r"C:\Users\Srikant Padhy\project\output\del.csv")

# for key,val in dic.items():
#     print(key,"====",val)


# txt = '''Credit Agreement regulated by the Consumer Credit Act 1974
# This Running Account Credit Agreement is between:
# This Bank (Close Brothers Limited trading as Close Brothers Premium Finance, Wimbledon Bridge House, 1 Hartfield Road, London, SW19 3RU); and
# The Customer (If a trading name is used, insert name and trading title, e.g. Sam Jones t/a Jones Export)'''
# def fnclasifypage(txt):
#     heading ="Credit Agreement regulated"
#     for line in txt.splitlines():
#         if line.__contains__(heading):
#             print(line)


'''filename = re.search(r'[^\\]+(?=\.png$)', file_name)
filename = filename.group()

with open(outDir+filename+ '.csv', 'w+') as f:
    key1 = ""
    for key, val in kvs.items():
        for i in df['Fields']:
            if key.strip() == str(i).strip():
                #df1.loc[0, i] = val
                f.write("%s,%s\n" % (i,val))
            else:
                f.write("%s,%s\n" % (i, " "))
            # elif key1!=i:
            #     f.write("%s,%s\n" % (i, " "))
            # else:
            #     print("test")'''