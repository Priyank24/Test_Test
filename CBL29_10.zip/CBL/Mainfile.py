import csv
#For going to respective folder we are using glob and os.
import glob,os
from textract_python_kv_parser import convert

mstconfigfile = r"C:\Users\Srikant Padhy\PycharmProjects\CBL\Masterconfig.csv"


'''this function will give how many pdf in filepath,
    and it will call the conver fuction from textract_python_kv_parser
    input filepath= inputpath,outpath=outputpath,originalformatpath=structure of output
     processing=for storing image'''
def fnextractCBL(filepath,outpath,originalformatpath,processing):
    all_pdf_file = glob.glob(os.path.join(filepath, '*.pdf'))
    for pdfs in all_pdf_file:
        convert(pdfs,outpath,originalformatpath,processing)

'''This is the main file to extract value from one cell in key value format 
    input is masterconfigfile where allpath are available
    output will be the all path like input,result,processing etc.'''
def main(mstconfigfile):
        Formfile=''
        with open(mstconfigfile) as f:
            reader = csv.DictReader(f)
            for row in reader:
                #print(row)
                if (row['Field'] != '' and row['Field']=='Filepath'):
                    filepath=row['Path']
                    print(filepath)
                if (row['Field'] != '' and row['Field'] == 'Result'):
                    outfile = row['Path']
                    print(outfile)
                if (row['Field'] != '' and row['Field'] == 'Originalformatpath'):
                    originalformatpath = row['Path']
                    print(originalformatpath)
                if (row['Field'] != '' and row['Field'] == 'Processing'):
                    processing = row['Path']
                    print(processing)
        fnextractCBL(filepath,outfile,originalformatpath,processing)
if __name__ == '__main__':
    main(mstconfigfile)
#


