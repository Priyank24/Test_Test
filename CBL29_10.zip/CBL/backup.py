import boto3
import sys
import re
import json
import csv
import pandas as pd
from pdf2image import convert_from_path

def get_kv_map(file_name):
    with open(file_name, 'rb') as file:
        img_test = file.read()
        bytes_test = bytearray(img_test)
        print('Image loaded', file_name)

    # process using image bytes
    client = boto3.client('textract')
    # s3BucketName = "ki-textract-demo-docs"
    # response = client.detect_document_text(Document={'S3Object': {'Bucket': s3BucketName,'Name': file_name}})
    response = client.analyze_document(Document={'Bytes': bytes_test}, FeatureTypes=['FORMS'])

    # Get the text blocks
    blocks = response['Blocks']

    # get key and value maps
    key_map = {}
    value_map = {}
    block_map = {}
    for block in blocks:
        block_id = block['Id']
        block_map[block_id] = block
        if block['BlockType'] == "KEY_VALUE_SET":
            if 'KEY' in block['EntityTypes']:
                key_map[block_id] = block
            else:
                value_map[block_id] = block

    return key_map, value_map, block_map


def get_kv_relationship(key_map, value_map, block_map):
    kvs = {}
    for block_id, key_block in key_map.items():
        value_block = find_value_block(key_block, value_map)
        key = get_text(key_block, block_map)
        val = get_text(value_block, block_map)
        kvs[key] = val
    return kvs


def find_value_block(key_block, value_map):
    for relationship in key_block['Relationships']:
        if relationship['Type'] == 'VALUE':
            for value_id in relationship['Ids']:
                value_block = value_map[value_id]
    return value_block


def get_text(result, blocks_map):
    text = ''
    if 'Relationships' in result:
        for relationship in result['Relationships']:
            if relationship['Type'] == 'CHILD':
                for child_id in relationship['Ids']:
                    word = blocks_map[child_id]
                    if word['BlockType'] == 'WORD':
                        text += word['Text'] + ' '
                    if word['BlockType'] == 'SELECTION_ELEMENT':
                        if word['SelectionStatus'] == 'SELECTED':
                            text += 'X '

    return text


def print_kvs(kvs):
    # filepath = r"C:\Users\Srikant Padhy\project\output\sequncefile1.csv"
    # # dic = {'DOB': 'test', 'Address': 'xyz', 'Broker Address': 'abcd efg', 'Post Code': '102050', 'Name': 'chinu'}
    # df = pd.read_csv(filepath, sep='\n')
    # df1 = pd.DataFrame()
    # for i in df['Fields']:
    #     for key, val in kvs.items():
    #         if i != '' and key.strip() == i.strip():
    #             df1.loc[0, i] = val
    #             print(val)
    # df1.to_csv(r'C:\Users\Srikant Padhy\project\output\test1.csv')
    for key, value in kvs.items():
        print(key, ":", value)

def search_value(kvs, search_key):
    for key, value in kvs.items():
        if re.search(search_key, key, re.IGNORECASE):
            return value



''''#it is main file to extract values as key value format.
#get_kv_map() function will call the AWS key and it will give the key value format and value in same cell in key value formats.
#get_kv_relationship input is get_kv_map function value and it will give key value format
#print_kvs() this function only for converting value to key value pairs
#input&output - it will take image as a input and it will call'''
#
def main(file_name):
    key_map, value_map, block_map = get_kv_map(file_name)

    # Get Key Value relationship
    kvs = get_kv_relationship(key_map, value_map, block_map)
    print("\n\n== FOUND KEY : VALUE pairs ===\n")
    print_kvs(kvs)
    for key, value in kvs.items():
        print(key, ":", value)
    filepath = r"C:\Users\Srikant Padhy\project\output\sequncefile1.csv"
    # dic = {'DOB': 'test', 'Address': 'xyz', 'Broker Address': 'abcd efg', 'Post Code': '102050', 'Name': 'chinu'}
    df = pd.read_csv(filepath, sep='\n')
    df1 = pd.DataFrame()
    with open(file_name + '.csv', 'w+') as f:
        for i in df['Fields']:
            for key, val in kvs.items():
                if i != ' ' and key.strip() == str(i).strip():
                    #df1.loc[0, i] = val
                    f.write("%s,%s\n" % (i,val))
    #df1.to_csv(r'C:\Users\Srikant Padhy\project\output',file_name,'.csv')
    #filename = re.match("([A-Za-z0-9]+)\.", file_name).group(1)
    #imagename=re.match("([A-Za-z0-9]+)\.",file).group(1)

    # with open(file_name+'.csv', 'w+') as f:
    #     for key in kvs.keys():
    #         f.write("%s,%s\n" % (key, kvs[key]))




# convert function will convert pdf to image
# input&output - it will take 2 argument one is pdf file path and second is the path where image will store.
def convert(file, outputDir):
    pages = convert_from_path(file, 500)
    counter = 1
    for page in pages:
        myfile = outputDir +'Page' + str(counter) +'.png'
        counter = counter + 1
        page.save(myfile, "JPEG")
        print(myfile)
        file_name = myfile
        main(file_name)




#test file
outputDir = r'C:\Users\Srikant Padhy\project\output\out_'
file = r"C:\Users\Srikant Padhy\project\Input\RACA_UK_Bordereau_0815.pdf"
convert(file, outputDir)
