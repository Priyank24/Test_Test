import csv
from pdf2image import convert_from_path
import pandas as pd
import boto3
from test import fnExtractPremiumandPayble,fnGrossRate,fnExtractAPR,indicativeTotalAmt,fnCreditArrangementFee





# with open(regex) as f:
#     reader = csv.DictReader(f)
#     for row in reader:
#         print(row['LineY'])
# def fnget_Allline(file_name,df):
#     print("fngetallline")
#     with open(file_name, 'rb') as file:
#         img_test = file.read()
#         bytes_test = bytearray(img_test)
#         #print('Image loaded', file_name)
#
#     # process using image bytes
#     client = boto3.client('textract')
#     response = client.detect_document_text(Document={'Bytes': bytes_test})
#
#
#     # Detect columns and print lines
#     columns = []
#     lines = []
#     for item in response["Blocks"]:
#         if item["BlockType"] == "LINE":
#             column_found = False
#             for index, column in enumerate(columns):
#                 bbox_left = item["Geometry"]["BoundingBox"]["Left"]
#                 bbox_right = item["Geometry"]["BoundingBox"]["Left"] + item["Geometry"]["BoundingBox"]["Width"]
#                 bbox_centre = item["Geometry"]["BoundingBox"]["Left"] + item["Geometry"]["BoundingBox"]["Width"] / 2
#                 column_centre = column['left'] + column['right'] / 2
#
#                 if (bbox_centre > column['left'] and bbox_centre < column['right']) or (
#                         column_centre > bbox_left and column_centre < bbox_right):
#                     # Bbox appears inside the column
#                     lines.append([index, item["Text"]])
#                     column_found = True
#                     break
#             if not column_found:
#                 columns.append({'left': item["Geometry"]["BoundingBox"]["Left"],
#                                 'right': item["Geometry"]["BoundingBox"]["Left"] + item["Geometry"]["BoundingBox"][
#                                     "Width"]})
#                 lines.append([len(columns) - 1, item["Text"]])
#
#     lines.sort(key=lambda x: x[0])
#     #df = pd.DataFrame()
#     word = 'a credit arrangement fee'
#     regex = r"C:\Users\Srikant Padhy\PycharmProjects\CBL\regex.csv"
#     with open(regex) as f:
#         reader = csv.DictReader(f)
#         for row in reader:
#             if (row['Fields'] != '' and row['Fields'] == 'premiumandpayble'):
#                 premiumandpayble = row['Fieldcontains']
#             if (row['Fields'] != '' and row['Fields'] == 'grossrate'):
#                 grosrate = row['Fieldcontains']
#                 print(grosrate)
#             if (row['Fields'] != '' and row['Fields'] == 'APR'):
#                 apr = row['Fieldcontains']
#                 print(apr)
#             if (row['Fields'] != '' and row['Fields'] == 'indictiveTotalamt'):
#                 indictive = row['Fieldcontains']
#                 print(indictive)
#             if (row['Fields'] != '' and row['Fields'] == 'CreditarrangementFee'):
#                 crarrangment = row['Fieldcontains']
#                 print(crarrangment)
#
#     for line in lines:
#         if str(line[1]).__contains__(grosrate.strip()):
#             fnGrossRate(line[1],df)
#         elif str(line[1]).__contains__(premiumandpayble.strip()):
#             fnExtractPremiumandPayble(line[1],df)
#         elif str(line[1]).__contains__(apr.strip()):
#             fnExtractAPR(line[1],df)
#         elif str(line[1]).__contains__(indictive.strip()):
#             indicativeTotalAmt(line[1],df)
#         elif str(line[1]).__contains__(crarrangment.strip()):
#             fnCreditArrangementFee(line[1],df)
#     print(df)
#     return df

