#To call the AWS key we using boto3
import boto3
import re
import pandas as pd
#converting pdf to image we are using below package
from pdf2image import convert_from_path
from extractbasedonpages import get_identifypage
#from test import fnExtractallStreamData
from AWSasAzure import fnget_Allline
def get_kv_map(file_name):
    with open(file_name, 'rb') as file:
        img_test = file.read()
        bytes_test = bytearray(img_test)
        print('Image loaded', file_name)

    # process using image bytes
    client = boto3.client('textract')
    # s3BucketName = "ki-textract-demo-docs"
    # response = client.detect_document_text(Document={'S3Object': {'Bucket': s3BucketName,'Name': file_name}})
    response = client.analyze_document(Document={'Bytes': bytes_test}, FeatureTypes=['FORMS'])

    # Get the text blocks
    blocks = response['Blocks']

    # get key and value maps
    key_map = {}
    value_map = {}
    block_map = {}
    for block in blocks:
        block_id = block['Id']
        block_map[block_id] = block
        if block['BlockType'] == "KEY_VALUE_SET":
            if 'KEY' in block['EntityTypes']:
                key_map[block_id] = block
            else:
                value_map[block_id] = block

    return key_map, value_map, block_map


def get_kv_relationship(key_map, value_map, block_map):
    kvs = {}
    for block_id, key_block in key_map.items():
        value_block = find_value_block(key_block, value_map)
        key = get_text(key_block, block_map)
        val = get_text(value_block, block_map)
        kvs[key] = val
    return kvs


def find_value_block(key_block, value_map):
    for relationship in key_block['Relationships']:
        if relationship['Type'] == 'VALUE':
            for value_id in relationship['Ids']:
                value_block = value_map[value_id]
    return value_block


def get_text(result, blocks_map):
    text = ''
    if 'Relationships' in result:
        for relationship in result['Relationships']:
            if relationship['Type'] == 'CHILD':
                for child_id in relationship['Ids']:
                    word = blocks_map[child_id]
                    if word['BlockType'] == 'WORD':
                        text += word['Text'] + ' '
                    if word['BlockType'] == 'SELECTION_ELEMENT':
                        if word['SelectionStatus'] == 'SELECTED':
                            text += 'X '

    return text

'''for printing the value in key value format we are using this function
 we will get kvs=dictionary'''
def print_kvs(kvs):
    for key, value in kvs.items():
        print(key, ":", value)


'''For searching the value based on key we are using this fuction'''
def search_value(kvs, search_key):
    for key, value in kvs.items():
        if re.search(search_key, key, re.IGNORECASE):
            return value


''''#it is main file to extract values as key value format.
#get_kv_map() function will call the AWS key and it will give the key value format and value in same cell in key value formats.
#get_kv_relationship input is get_kv_map function value and it will give key value format
#print_kvs() this function only for converting value to key value pairs
#input&output - it will take image as a input and it will call'''
#
def fnGetData(file_name,outDir,originalformatpath):
    print("inside analizepage")
    key_map, value_map, block_map = get_kv_map(file_name)
    # Get Key Value relationship
    kvs = get_kv_relationship(key_map, value_map, block_map)
    print("\n\n== FOUND KEY : VALUE pairs ===\n")
    print_kvs(kvs)
    # for key, value in kvs.items():
    #     print(key, ":", value)
    #filepath = r"C:\Users\Srikant Padhy\project\output\sequncefile1.csv"
    # dic = {'DOB': 'test', 'Address': 'xyz', 'Broker Address': 'abcd efg', 'Post Code': '102050', 'Name': 'chinu'}
    df = pd.read_csv(originalformatpath, sep='\n')
    df1 = pd.DataFrame()
    dfs = fnget_Allline(file_name)
    for data in df['Fields']:
        for key, val in kvs.items():
            if str(data).strip() == key.strip():
                dfs.loc[0, data] = val
            else:
                dfs.loc[1, data] = ' '
    #df1.drop(index=[1], inplace=True)

    #df1.drop(index = 1, inplace = True)
    # dfs = fnget_Allline(file_name)

    # frame = [df1,dfs]
    # df1 = pd.concat(frame,axis=1,ignore_index=False,sort=False)
    #df1 = df1.merge(dfs)
    #df1 = df1.append(dfs,ignore_index=True)

    #df1 = df1.transpose()
    filename = re.search(r'[^\\]+(?=\.png$)', file_name)
    filename = filename.group()
    dfs.to_csv(outDir+filename+'.csv')

    return df1
def fnGetData1(file_name,outDir,originalformatpath):
    print("inside analizepage")
    key_map, value_map, block_map = get_kv_map(file_name)
    # Get Key Value relationship
    kvs = get_kv_relationship(key_map, value_map, block_map)
    print("\n\n== FOUND KEY : VALUE pairs ===\n")
    df1 = pd.DataFrame()
    for key, value in kvs.items():
        if key == 'Postcode  ':
            df1.loc[0,'postcode'] = value
        if key == 'Bank/building society account number  ':
            df1.loc[0,'postcode'] = value
    filename = re.search(r'[^\\]+(?=\.png$)', file_name)
    filename = filename.group()
    df1.to_csv(outDir + filename + '.csv')


'''convert function will convert pdf to image
    input&output -file= pdf,outpath=outputpath,originalformatpath=structure of output
     processing=for storing image'''

def convert(file,outputDir,orginalformatpath,processing):
    pages = convert_from_path(file, 500)
    counter = 1
    filename = re.search(r'[^\\]+(?=\.pdf$)', file)
    filename = filename.group()
    for page in pages:
        myfile = processing + filename + str(counter) +'.png'
        counter = counter + 1
        page.save(myfile, "JPEG")
        print(myfile)
        file_name = myfile
        if get_identifypage(file_name) == 1:
            #Extractbasedonpages need to add
            fnGetData(file_name,outputDir,orginalformatpath)
        if get_identifypage(file_name) == 2:
            fnGetData1(file_name,outputDir,orginalformatpath)


# #test file
# outputDir = r'C:\Users\Srikant Padhy\project\output\out_'
# file = r"C:\Users\Srikant Padhy\project\Input\RACA_UK_Bordereau_0815.pdf"
#orginalfilepath = r"C:\Users\Srikant Padhy\project\output\sequncefile1.csv"
# convert(file, outputDir,orginalfilepath)
