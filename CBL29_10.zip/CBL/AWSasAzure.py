#To call the AWS key we using boto3
import boto3
#For data manupultion and createing Dataframe we are using pandas
import pandas as pd
#For mathmatical operation we are using numpy
import numpy as np
#converting pdf to image we are using pdf2image.
from pdf2image import convert_from_path
import re,csv
from test import fnExtractPremiumandPayble,fnGrossRate,fnExtractAPR,indicativeTotalAmt,fnCreditArrangementFee
'''it will take image as input and give the nearst line in y4'''

def get_kv_map(file_name):
    with open(file_name, 'rb') as file:
        img_test = file.read()
        bytes_test = bytearray(img_test)
        print('Image loaded', file_name)

    # process using image bytes
    client = boto3.client('textract')
    #response = client.detect_document_text(Document={'S3Object': {'Bucket': s3BucketName,'Name': file_name}})
    response = client.detect_document_text(Document={'Bytes': bytes_test})
    print(response)
    columns = []
    finalDf = df = pd.DataFrame(columns=['text', 'x1', 'y1', 'x2', 'y2','x3','y3','x4','y4'])
    dfIndex = 0
    for item in response["Blocks"]:
        w = item["Geometry"]["BoundingBox"]['Width']
        h = item["Geometry"]["BoundingBox"]['Height']
        x = item["Geometry"]["BoundingBox"]['Left']
        y = item["Geometry"]["BoundingBox"]['Top']
        #print(x, y, w, h)
        x1, y1, x2, y2, x3, y3, x4, y4 = x, y, x + w, y, x + w, y + h, x, y + h
        #print(x1,"==", y1,"==", x2,"==", y2,"==", x3,"==", y3,"==", x4,"==", y4 )
        #word = item['Text']
        word = item.get('Text')
        finalDf.loc[dfIndex] = [word, x1, y1, x2, y2, x3, y3, x4, y4]
        dfIndex+=1
    #print(finalDf)
    #finalDf.to_excel('test.xlsx')

    finalDf.to_csv(r'C:\Users\Srikant Padhy\demo\venv\input\tempfile.csv')
    df = pd.read_csv(r'C:\Users\Srikant Padhy\demo\venv\input\tempfile.csv')

    df.rename(columns={'text': 'word'}, inplace=True)
    df.rename(columns={'x1': 'Hori'}, inplace=True)
    df.rename(columns={'y1': 'Y'}, inplace=True)
    # df = df.drop(df.index[0])
    #df = df.drop(columns=["x2", "x4", "y2", "y4"])
    # df = df.sort_values('Hori','y1')
    # df = df.sort_values('Y')
    srk = df
    srk['W'] = df['x3'] - df['Hori']
    srk['H'] = df['y3'] - df['Y']
    # mode_h  =srk['H'].mode()
    median_h = np.median(srk['H'])

    #print(median_h)
    lst_line_y = []
    y_val_Prev = 0
    LineY = 0
    for index, row in srk.iterrows():
        if index == 0:
            y_val_Prev = row['Y']
            lst_line_y.append(y_val_Prev)
            LineY = y_val_Prev
        if index > 0:
            if int(row['Y']) - int(y_val_Prev) >= int(median_h):
                # print(int(row['Y']) - int(y_val_Prev))
                lst_line_y.append(row['Y'])
                LineY = row['Y']
            else:
                lst_line_y.append(LineY)
        y_val_Prev = row['Y']
    srk['LineY'] = lst_line_y
    srk = srk.sort_values(['LineY', 'Hori'], ascending=[True, True])
    #print(srk)

    srk.to_csv(r'C:\Users\Srikant Padhy\demo\venv\input\tmp_output.csv')




'''it will take image as input and give the data line by line'''

def fnget_Allline(file_name):
    with open(file_name, 'rb') as file:
        img_test = file.read()
        bytes_test = bytearray(img_test)
        #print('Image loaded', file_name)

    # process using image bytes
    client = boto3.client('textract')
    response = client.detect_document_text(Document={'Bytes': bytes_test})


    # Detect columns and print lines
    columns = []
    lines = []
    for item in response["Blocks"]:
        if item["BlockType"] == "LINE":
            column_found = False
            for index, column in enumerate(columns):
                bbox_left = item["Geometry"]["BoundingBox"]["Left"]
                bbox_right = item["Geometry"]["BoundingBox"]["Left"] + item["Geometry"]["BoundingBox"]["Width"]
                bbox_centre = item["Geometry"]["BoundingBox"]["Left"] + item["Geometry"]["BoundingBox"]["Width"] / 2
                column_centre = column['left'] + column['right'] / 2

                if (bbox_centre > column['left'] and bbox_centre < column['right']) or (
                        column_centre > bbox_left and column_centre < bbox_right):
                    # Bbox appears inside the column
                    lines.append([index, item["Text"]])
                    column_found = True
                    break
            if not column_found:
                columns.append({'left': item["Geometry"]["BoundingBox"]["Left"],
                                'right': item["Geometry"]["BoundingBox"]["Left"] + item["Geometry"]["BoundingBox"][
                                    "Width"]})
                lines.append([len(columns) - 1, item["Text"]])

    lines.sort(key=lambda x: x[0])
    df = pd.DataFrame()
    word = 'a credit arrangement fee'
    regex = r"C:\Users\Srikant Padhy\PycharmProjects\CBL\regex.csv"
    with open(regex) as f:
        reader = csv.DictReader(f)
        for row in reader:
            if (row['Fields'] != '' and row['Fields'] == 'premiumandpayble'):
                premiumandpayble = row['Fieldcontains']
            if (row['Fields'] != '' and row['Fields'] == 'grossrate'):
                grosrate = row['Fieldcontains']
                print(grosrate)
            if (row['Fields'] != '' and row['Fields'] == 'APR'):
                apr = row['Fieldcontains']
                print(apr)
            if (row['Fields'] != '' and row['Fields'] == 'indictiveTotalamt'):
                indictive = row['Fieldcontains']
                print(indictive)
            if (row['Fields'] != '' and row['Fields'] == 'CreditarrangementFee'):
                crarrangment = row['Fieldcontains']
                print(crarrangment)

    for line in lines:
        if str(line[1]).__contains__(grosrate.strip()):
            fnGrossRate(line[1],df)
        elif str(line[1]).__contains__(premiumandpayble.strip()):
            fnExtractPremiumandPayble(line[1],df)
        elif str(line[1]).__contains__(apr.strip()):
            fnExtractAPR(line[1],df)
        elif str(line[1]).__contains__(indictive.strip()):
            indicativeTotalAmt(line[1],df)
        elif str(line[1]).__contains__(crarrangment.strip()):
            fnCreditArrangementFee(line[1],df)

    return df



''''#it is main file to extract values as key value format.
#get_kv_map() function will call the AWS key and tempfile.csv y4 column will show 2 value are in same line or not.
#get_Allline() will give all string line by line and print all value in console.
#input&output - it will take image as a input and it will call'''
def main(file_name):

    # filename = re.match("([A-Za-z0-9]+)\.", file_name).group(1)
    # imagename = re.match("([A-Za-z0-9]+)\.", file).group(1)
    get_kv_map(file_name)
    #fnget_Allline(file_name)

#
# def fnclasifypage(txt):
#     heading ="Credit Agreement regulated"
#     for line in txt.splitlines():
#         if line.__contains__(heading):
#             print(line)

'''# convert function will convert pdf to image
# input&output - it will take 2 argument one is pdf file path and second is the path where image will store.'''
def convert(file, outputDir):
    pages = convert_from_path(file, 500)
    counter = 1
    for page in pages:
        myfile = outputDir +'Page' + str(counter) +'.jpg'
        counter = counter + 1
        page.save(myfile, "JPEG")
        print(myfile)
        file_name = myfile
        main(file_name)
outputDir = r'C:\Users\Srikant Padhy\project\output\out_'
file = r"C:\Users\Srikant Padhy\Desktop\RACA_UK_Bordereau_0815.pdf"
convert(file, outputDir)
filepath=r"C:\Users\Srikant Padhy\demo\venv\input\RACA_UK_Bordereau_0815-1.jpg"
# get_Oneline_data  = get_kv_map(filepath)
# get_allline = get_Allline(filepath)
